1. install java
2.To run the RL simulating program, go to RL_sim folder, use this command: java -jar rl_sim.jar
3. The two MDP problem that I created are called MAZE1.maze/MAZE1-penalty100.maze and MAZE2.maze/MAZE2-penalty100.maze
4.To use the two mazes, please load them from the mazes folder, the instruction for using the program can be found in RL_sim/help
5. The original RL_sim program can be found at https://www.cs.cmu.edu/~awm/rlsim/